package dao;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class DAOFactoryTest {

	@Test
	public void testDAOFactoryMySQL() {
		assertNotNull(DAOFactory.getDAOFactory(DAOFactory.MYSQL));
	}

	@Test
	public void testDAOFactorygetKlantDAOMySQL() {
		assertNotNull(DAOFactory.getDAOFactory(DAOFactory.MYSQL).getKlantDAO());
	}

}
